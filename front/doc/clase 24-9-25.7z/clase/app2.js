//simular una bd
const usuarios = [
  { id: 1, nombre: "Ana" },
  { id: 2, nombre: "Carlos" },
  { id: 3, nombre: "Pedro" },
];

const parse = JSON.stringify(usuarios); // convertirlo a json

const objNormal = JSON.parse(parse); // convertirlo a obj javascript

//buscar usuario por id
const buscarUsuarioId = (id, callback) => {
  console.log("Buscado usuario...");
  //simulacion consulta de bd
  setTimeout(() => {
    const resultado = usuarios.find((user) => user.id === id);
    if (resultado === undefined) {
      //decirle algo salio mal
      callback("El usuario no se encontro", null);
    } else {
      //todo esta bien lo mando asi
      callback(null, resultado);
    }
  }, 1000);
};

const printResultado = (error, resultado) => {
  if (error) {
    console.log(error);
  } else {
    console.log("Usuario encontrado", resultado);
  }
};

//buscarUsuarioId(1, printResultado);

const buscarUsuarioPromesa = (id) => {
  // si todo esta bien ejectamos resolve si esta mal reject
  return new Promise((resolve, reject) => {
    console.log("buscando usuario....");
    setTimeout(() => {
      const resultado = usuarios.find((user) => user.id === id);
      if (!resultado) {
        reject("el resultado no se encontro");
        return;
      }
      resolve(resultado);
    }, 1000);
  });
};
//resolvemos promesa de manera normal
// buscarUsuarioPromesa(10) // esta en pending
//   .then((resultado) => console.log("se encontro", resultado)) // ejecuto resolved

//   .catch((err) => console.log(err)); // ejecuto  reject

//resolvemos promesa con async y await

const resolverPromesaAsync = async (id) => {
  try {
    const resultado = await buscarUsuarioPromesa(id); //paso esta
    console.log(resultado);
  } catch (error) {
    console.log(error);
  }
};

//resolverPromesaAsync(1);
const URL = "https://rickandmortyapi.com/api/character";
//fetch funciona como un get => http => get trae info
fetch(URL) //llame al endpoint
  .then((response) => response.json()) //convierto a un dato trabajable
  .then((data) => console.log(data)); //obtengo mi data

const getDataApi = async () => {
  try {
    const response = await fetch(URL);
    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.log("algo salio mal");
  }
};
getDataApi();
